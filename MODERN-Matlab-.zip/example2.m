% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    Example 2                                                            %
%                                                                         %
%                                                                         %
% This is Example 2 in Chellaboina et al (2009)                           %
%                                                                         %
% RESULT: The chemical reaction network corresponding to the ordinary     %
%    differential equations is given by:                                  %
%                                                                         %
%    R1: X1+X2 -> 2X1                                                     %
%    R2: 2X1 -> X1+X2                                                     %
%                                                                         %
% Reference: Chellaboina V, Bhat S, Haddad W, Bernstein D (2009) Modeling %
%    and analysis of mass-action kinetics. IEEE Control Syst 29(4):60-78. %
%    https://doi.org/10.1109/MCS.2009.932926.                             %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Name of the ODE system
ode.id = 'Example 2';

% Fluxes
ode = addFlux(ode, 'v1', 'k1 X1 X2', ...     % flux v1
                         {{'X1', 'X2'}}, ... % species in the flux
                         {{1, 1}});          % kinetic (exponent) of the species
ode = addFlux(ode, 'v2', 'k2 X1^2', ...
                         {{'X1'}}, ...
                         {{2}});

% Flux balance equations
ode = addEquation(ode, 'X1', 'v1-v2', ...        % ODE for X1
                             {{'v1', 'v2'}}, ... % fluxes in the ODE
                             {{1, -1}});         % coefficients (stoichiometry) of the fluxes
ode = addEquation(ode, 'X2', '-v1+v2', ...
                             {{'v1', 'v2'}}, ...
                             {{-1, 1}});

% Convert the ODE system to CRN
ode = odeToCRN(ode);