% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                         %
%    addFlux                                                              %
%                                                                         %
%                                                                         %
% OUTPUT: Returns a structure called 'ode' with added field 'reaction'    %
%    with subfields 'id' (with further subfields 'var' and 'flux'),       %
%    'species', and 'kinetic' (see README.txt for details). The output    %
%    variable 'ode' allows the user to view the ordinary differential     %
%    equations with the added reaction.                                   %
%                                                                         %
% INPUTS:                                                                 %
%    - ode: a structure, representing the ordinary differential equations %
%         (see README.txt for details on how to fill out the structure)   %
%    - var: variable representing the flux (string)                       %
%    - flux: a visual representation of the flux (string)                 %
%    - species: list of species involved in the reaction (cell within a   %
%         cell)                                                           %
%    - kinetic: list of kinetic orders (exponents) of the species (cell   %
%         within a cell)                                                  %
%                                                                         %
% Created: 18 July 2022                                                   %
% Last Modified: 18 July 2022                                             %
%                                                                         %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



function ode = addFlux(ode, var, flux, species, kinetic)

    % For succeeding reactions
    try
        ode.reaction(end+1) = struct('id', struct('var', var, 'flux', flux), 'species', species, 'kinetic', kinetic);
    
    % For the first reaction
    catch
        ode.reaction(1) = struct('id', struct('var', var, 'flux', flux), 'species', species, 'kinetic', kinetic);
    end

end