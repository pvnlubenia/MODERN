% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                             %
%    Example 1                                                                %
%                                                                             %
%                                                                             %
% This is Example 1 in Chellaboina et al (2009)                               %
%                                                                             %
% RESULT: The chemical reaction network corresponding to the ordinary         %
%            differential equations is given by:                              %
%                                                                             %
%            R1: X1 -> X2                                                     %
%            R2: X2 -> X1                                                     %
%                                                                             %
% Reference: Chellaboina, V., Bhat, S.P., Haddad, W.M., and Bernstein, D.S.   %
%    (2009). Modeling and analysis of mass-action kinetics. IEEE Control      %
%    Systems, 29(4) 60-78. doi:10.1109/MCS.2009.932926.                       %
%                                                                             %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



% Clear all variables
clear all

% Name of the ODE system
ode.id = 'Example 1';

% Initialize list of species and fluxes
ode.species = { };
ode.flux = { };

% Kinetics
ode.reaction(1) = struct('id', struct('var', 'v1', 'eq', 'k1 X1'), 'species', {{'X1'}}, 'order', {{1}});
ode.reaction(2) = struct('id', struct('var', 'v2', 'eq', 'k2 X2'), 'species', {{'X2'}}, 'order', {{1}});

% Flux balance equations
ode.equation(1) = struct('id', struct('var', 'X1', 'eq', '-v1+v2'), 'flux', {{'v1', 'v2'}}, 'coeff', {{-1, 1}});
ode.equation(2) = struct('id', struct('var', 'X2', 'eq', 'v1-v2'), 'flux', {{'v1', 'v2'}}, 'coeff', {{1, -1}});



% Convert the ODE system to CRN
[ode] = ode_to_crn(ode);