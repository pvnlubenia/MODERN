% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%                                                                           %
%    addEquation                                                            %
%                                                                           %
%                                                                           %
% OUTPUT: Returns a structure called 'ode' with added field 'equation'      %
%    with subfields 'id' (with further subfields 'var' and 'flux'),         %
%    'flux', and 'coeff' (see README.txt for details). The output           %
%    variable 'ode' allows the user to view the ordinary differential       %
%    equations with the added equation.                                     %
%                                                                           %
% INPUTS:                                                                   %
%    - ode: a structure, representing the ordinary differential equations   %
%         (see README.txt for details on how to fill out the structure)     %
%    - var: variable representing the state variable (string)               %
%    - eq: a visual representation of the flux balance expression (string)  %
%    - flux: list of fluxes involved in the ODE (cell within a              %
%         cell)                                                             %
%    - coeff: list of coefficients (stoichiometry) of the fluxes (cell      %
%         within a cell)                                                    %
%                                                                           %
% Created: 18 July 2022                                                     %
% Last Modified: 18 July 2022                                               %
%                                                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %



function ode = addEquation(ode, var, eq, flux, coeff)

    % For succeeding reactions
    try
        ode.equation(end+1) = struct('id', struct('var', var, 'eq', eq), 'flux', flux, 'coeff', coeff);
    
    % For the first reaction
    catch
        ode.equation(1) = struct('id', struct('var', var, 'eq', eq), 'flux', flux, 'coeff', coeff);
    end

end